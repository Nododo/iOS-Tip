//
//  XFFile.h
//  XFlags
//
//  Created by nark on 24/01/11.
//  Copyright 2011 OPALE. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <SecurityFoundation/SFAuthorization.h>
#include <sys/stat.h>
#include <unistd.h>


enum XFVisibility { 
	HIDDEN, 
	VISIBLE, 
	UNKNOWN 
} typedef XFVisibility;


@interface XFFile : NSObject {
	NSString *filePath;
	SFAuthorization *myAuthorization;
}

@property (readwrite, retain) NSString *filePath;

+ (id)fileWithPath:(NSString *)_filepath;
- (id)initWithPath:(NSString *)_filepath;

- (NSString *)fileName;

- (BOOL)isHidden;
- (BOOL)setHidden:(BOOL)_hidden;

- (BOOL)isLocked;
- (void)setLocked:(BOOL)_locked;

- (BOOL)isDirectory;

- (BOOL)hide;
- (BOOL)show;

- (BOOL)lock;
- (BOOL)unlock;

@end
